cd server
java -Xms512M -Xmx1024M -jar spigot-1.19.4.jar -o true

