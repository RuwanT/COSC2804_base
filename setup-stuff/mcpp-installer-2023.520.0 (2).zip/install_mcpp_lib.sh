# Copies files with overwrite to the common C++ library locations.
cp ./libmcpp.a /usr/local/lib/
cp -r ./include/mcpp /usr/local/include/
