#! /bin/bash
python3 -m pip install MC_Py_API.zip
